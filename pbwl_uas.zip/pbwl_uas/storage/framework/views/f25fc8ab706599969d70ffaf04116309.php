

<?php $__env->startSection('content'); ?>
    <h2>Add Barang</h2>

    <form action="<?php echo e(url('barang')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="">KODE BARANG</label>
            <input type="text" name="kode_barang" id="" class="form-control">
        </div>
        <div class="mb-3">
            <label for="">NAMA BARANG</label>
            <input type="text" name="nama_barang" id="" class="form-control">
        </div>
        <div class="mb-3">
            <label for="">HARGA BARANG</label>
            <input type="text" name="harga_barang" id="" class="form-control">
        </div>
        <div class="mb-3">
            <label for="">STOCK BARANG</label>
            <input type="text" name="stock_barang" id="" class="form-control">
        </div>
        <div class="mb-3">
            <input type="submit" value="SAVE" class="btn btn-primary">
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwl_uas\resources\views/barang/create.blade.php ENDPATH**/ ?>