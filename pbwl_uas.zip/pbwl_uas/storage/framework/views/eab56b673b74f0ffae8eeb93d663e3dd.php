
<?php $__env->startSection('content'); ?>

<div class="container">

<h3>Daftar Barang</h3>

<a href="<?php echo e(url('barang/create')); ?>" class="btn btn-primary mb-3 float-end">Add Barang</a>

<table class="table table-bordered">
      <tr>
            <th>KODE BARANG</th>
            <th>NAMA BARANG</th>
            <th>HARGA BARANG</th>
            <th>STOCK BARANG</th>
            <th>EDIT</th>
            <th>DELETE</th>
      </tr>

      <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                  <td><?php echo e($row->kode_barang); ?></td>
                  <td><?php echo e($row->nama_barang); ?></td>
                  <td><?php echo e($row->harga_barang); ?></td>
                  <td><?php echo e($row->stock_barang); ?></td>
                  <td><a href="<?php echo e(url('barang/edit/' . $row->id)); ?>" class="btn btn-warning">Edit</a></td>
                  <td>
                        <form action="<?php echo e(url('barang/' . $row->id)); ?>" method="post">
                              <input type="hidden" name="_method" value="DELETE">
                              <?php echo csrf_field(); ?>
                              <input type="submit" value="Delete" class="btn btn-danger" onclick="return confirm('Apakah Kamu Yakin Ingin Menghapus Data Ini?')">
                        </form>
                  </td>
            </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwl_uas\resources\views/barang/index.blade.php ENDPATH**/ ?>