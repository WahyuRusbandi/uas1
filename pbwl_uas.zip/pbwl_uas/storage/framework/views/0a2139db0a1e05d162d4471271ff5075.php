

<?php $__env->startSection('content'); ?>
    <h2>Add Pelanggan</h2>

    <form action="<?php echo e(url('pelanggan')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="">ID PELANGGAN</label>
            <input type="text" name="gol_id" id="" class="form-control">
        </div>
        <div class="mb-3">
            <label for="">KODE PELANGGAN</label>
            <input type="text" name="pel_no" id="" class="form-control">
        </div>
        <div class="mb-3">
            <label for="">NAMA PELANGGAN</label>
            <input type="text" name="pel_nama" id="" class="form-control">
        </div>
        <div class="mb-3">
            <label for="">NAMA BARANG</label>
            <input type="text" name="pel_alamat" id="" class="form-control">
        </div>
        <div class="mb-3">
            <label for="">TOTAL PEMBELIAN</label>
            <input type="text" name="pel_hp" id="" class="form-control">
        </div>
        <div class="mb-3">
            <label for="">UANG BAYAR</label>
            <input type="text" name="pel_ktp" id="" class="form-control">
        </div>
        <div class="mb-3">
            <input type="submit" value="SAVE" class="btn btn-primary">
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwl_uas\resources\views/pelanggan/create.blade.php ENDPATH**/ ?>