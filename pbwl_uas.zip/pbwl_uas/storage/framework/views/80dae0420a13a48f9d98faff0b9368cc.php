
<?php $__env->startSection('content'); ?>

<div class="container">

<h3>Daftar Pelanggan</h3>

<a href="<?php echo e(url('pelanggan/create')); ?>" class="btn btn-primary mb-3 float-end">Add Pelanggan</a>

<table class="table table-bordered">
      <tr>
            <th>ID GOL</th>
            <th>NO PELANGGAN</th>
            <th>NAMA</th>
            <th>ALAMAT</th>
            <th>HP</th>
            <th>KTP</th>
            <th>SERI</th>
            <th>METERAN</th>
            <th>AKTIF</th>
            <th>ID USER</th>
            <th>EDIT</th>
            <th>DELETE</th>
      </tr>

      <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                  <td><?php echo e($row->gol_id); ?></td>
                  <td><?php echo e($row->pel_no); ?></td>
                  <td><?php echo e($row->pel_nama); ?></td>
                  <td><?php echo e($row->pel_alamat); ?></td>
                  <td><?php echo e($row->pel_hp); ?></td>
                  <td><?php echo e($row->pel_ktp); ?></td>
                  <td><?php echo e($row->pel_seri); ?></td>
                  <td><?php echo e($row->pel_meteran); ?></td>
                  <td><?php echo e($row->pel_aktif); ?></td>
                  <td><?php echo e($row->user_id); ?></td>
                  <td><a href="<?php echo e(url('pelanggan/edit/' . $row->pel_id)); ?>" class="btn btn-warning">Edit</a></td>
                  <td>
                        <form action="<?php echo e(url('pelanggan/' . $row->pel_id)); ?>" method="post">
                              <input type="hidden" name="_method" value="DELETE">
                              <?php echo csrf_field(); ?>
                              <input type="submit" value="Delete" class="btn btn-danger" onclick="return confirm('Are you sure?')">
                        </form>
                  </td>
            </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwl-quiz\resources\views/pelanggan/index.blade.php ENDPATH**/ ?>