<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Barang;

class BarangController extends Controller
{
     /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $rows = Barang::all();
        return view('barang.index', compact('rows'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('barang.create');
    }

     /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'id' => 'bail|required|unique:tb_barang  ',
            'kode_barang' => 'required'
        ],
        [
            'id.required' => 'Id golongan wajib diisi',
            'id.unique' => 'Kode sudah ada',
            'kode_barang.required' => 'kode wajib diisi'
        ]);

        Barang::create([
            'id' => $request->id,
            'kode_barang' => $request->kode_barang,
            'nama_barang' => $request->nama_barang,
            'harga_barang' => $request->harga_barang,
            'stock_barang' => $request->stock_barang
        ]);

        return redirect('barang');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $row = Barang::findOrFail($id);
        return view('barang.edit', compact('row'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $request->validate(
            [
            'id' => 'bail|required',
            'kode_barang' => 'required'
        ],
        [
            'id.required' => 'Kode sudah ada',
            'kode_barang.required' => 'kode wajib diisi'
        ]);

        $row = Barang::findOrFail($id);
        $row->update([
            'id' => $request->id,
            'kode_barang' => $request->kode_barang,
            'nama_barang' => $request->nama_barang,
            'harga_barang' => $request->harga_barang,
            'stock_barang' => $request->stock_barang
        ]);
        
        return redirect('barang');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $row = Barang::findOrFail($id);
        $row->delete();

        return redirect('barang');
    }
}

