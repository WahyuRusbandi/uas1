@extends('layouts.app')
@section('content')

<div class="container">

<h3>Daftar Pelanggan</h3>

<a href="{{ url('pelanggan/create') }}" class="btn btn-primary mb-3 float-end">Add Pelanggan</a>

<table class="table table-bordered">
      <tr>
            <th>KODE PELANGGAN</th>
            <th>NAMA PELANGGAN</th>
            <th>NAMA BARANG</th>
            <th>TOTAL PEMBELIAN</th>
            <th>UANG BAYAR</th>
            <th>EDIT</th>
            <th>DELETE</th>
      </tr>

      @foreach ($rows as $row)
            <tr>
                  <td>{{ $row->kode_pelanggan }}</td>
                  <td>{{ $row->nama_pelanggan }}</td>
                  <td>{{ $row->nama_barang }}</td>
                  <td>{{ $row->total pembelian }}</td>
                  <td>{{ $row->uang_bayar }}</td>
                  <td><a href="{{ url('pelanggan/edit/' . $row->pel_id) }}" class="btn btn-warning">Edit</a></td>
                  <td>
                        <form action="{{ url('pelanggan/' . $row->pel_id) }}" method="post">
                              <input type="hidden" name="_method" value="DELETE">
                              @csrf
                              <input type="submit" value="Delete" class="btn btn-danger" onclick="return confirm('Apakah Kamu Yakin Ingin Menghapus Data Ini?')">
                        </form>
                  </td>
            </tr>
      @endforeach

</table>

@endsection