@extends('layouts.app')

@section('content')
    <h2>Edit Pelanggan</h2>
    <div class="container">

    <form action="{{ url('pelanggan/' . $row->id_pelanggan) }}" method="post">
        @method('PATCH')
        @csrf
        <div>
        <div class="mb-3">
            <label for="">ID PELANGGAN</label>
            <input type="text" name="id_pelanggan" id="" class="form-control" value="{{ $row->id_pelanggan }}"></>
        </div>
        <div>
        <div class="mb-3">
            <label for="">KODE PELANGGAN</label>
            <input type="text" name="kode_pelanggan" id="" class="form-control" value="{{ $row->kode_pelanggan }}"></>
        </div>
        <div>
        <div class="mb-3">
            <label for="">NAMA PELANGGAN</label>
            <input type="text" name="nama_pelanggan" id="" class="form-control" value="{{ $row->nama_pelanggan }}"></>
        </div>
        <div>
        <div class="mb-3">
            <label for="">NAMA BARANG</label>
            <input type="text" name="nama_barang" id="" class="form-control" value="{{ $row->nama_barang }}"></>
        </div>
        <div>
        <div class="mb-3">
            <label for="">TOTAL PEMBELIAN</label>
            <input type="text" name="total pembelian" id="" class="form-control" value="{{ $row->total pembelian }}"></>
        </div>
        <div>
        <div class="mb-3">
            <label for="">UANG BAYAR</label>
            <input type="text" name="uang-bayar" id="" class="form-control" value="{{ $row->uang-bayar }}"></>
        </div>
        <div class="mb-3">
            <input type="submit" value="UPDATE" class="btn btn-primary">
        </div>
    </form>
@endsection
