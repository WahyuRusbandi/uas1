@extends('layouts.app')

@section('content')
    <h2>Edit Barang</h2>
    <div class="container">

    <form action="{{ url('barang/' . $row->id) }}" method="post">
        @method('PATCH')
        @csrf
        <div>
        <div class="mb-3">
            <label for="">KODE BARANG</label>
            <input type="text" name="kode_barang" id="" class="form-control" value="{{ $row->kode_barang }}"></>
        </div>
        <div>
        <div class="mb-3">
            <label for="">NAMA BARANG</label>
            <input type="text" name="nama_barang" id="" class="form-control" value="{{ $row->nama_barang }}"></>
        </div>
        <div>
        <div class="mb-3">
            <label for="">HARGA BARANG</label>
            <input type="text" name="harga_barang" id="" class="form-control" value="{{ $row->harga_barang }}"></>
        </div>
        <div>
        <div class="mb-3">
            <label for="">STOCK BARANG</label>
            <input type="text" name="stock_barang" id="" class="form-control" value="{{ $row->stock_barang }}"></>
        </div>
        <div class="mb-3">
            <input type="submit" value="UPDATE" class="btn btn-primary">
        </div>
    </form>
@endsection
