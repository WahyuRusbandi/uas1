@extends('layouts.app')
@section('content')

<div class="container">

<h3>Daftar Barang</h3>

<a href="{{ url('barang/create') }}" class="btn btn-primary mb-3 float-end">Add Barang</a>

<table class="table table-bordered">
      <tr>
            <th>KODE BARANG</th>
            <th>NAMA BARANG</th>
            <th>HARGA BARANG</th>
            <th>STOCK BARANG</th>
            <th>EDIT</th>
            <th>DELETE</th>
      </tr>

      @foreach ($rows as $row)
            <tr>
                  <td>{{ $row->kode_barang }}</td>
                  <td>{{ $row->nama_barang }}</td>
                  <td>{{ $row->harga_barang }}</td>
                  <td>{{ $row->stock_barang }}</td>
                  <td><a href="{{ url('barang/edit/' . $row->id) }}" class="btn btn-warning">Edit</a></td>
                  <td>
                        <form action="{{ url('barang/' . $row->id) }}" method="post">
                              <input type="hidden" name="_method" value="DELETE">
                              @csrf
                              <input type="submit" value="Delete" class="btn btn-danger" onclick="return confirm('Apakah Kamu Yakin Ingin Menghapus Data Ini?')">
                        </form>
                  </td>
            </tr>
      @endforeach

</table>

@endsection